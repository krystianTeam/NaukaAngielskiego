


var user = {};

$(function () {
   
    
    //document.addEventListener("backbutton", onBackKeyDown, false);
    var apk = new Apk.apk();
    apk.init(); 
});